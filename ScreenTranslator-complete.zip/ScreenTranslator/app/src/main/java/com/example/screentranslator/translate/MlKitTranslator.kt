package com.example.screentranslator.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

/**
 * 离线翻译管理
 * 支持常用语言包一键下载与切换
 */
object MlKitTranslator {

    private var currentTranslator: Translator? = null
    private var currentSource: String = TranslateLanguage.ENGLISH
    private var currentTarget: String = TranslateLanguage.CHINESE

    data class LanguagePack(
        val displayName: String,
        val sourceLang: String,
        val targetLang: String,
        val description: String
    )

    /** 常用语言包列表（可继续扩展） */
    val COMMON_PACKS = listOf(
        LanguagePack("英语 → 中文", TranslateLanguage.ENGLISH, TranslateLanguage.CHINESE, "最常用，适合绝大多数场景"),
        LanguagePack("日语 → 中文", TranslateLanguage.JAPANESE, TranslateLanguage.CHINESE, "适合漫画、游戏、日剧"),
        LanguagePack("韩语 → 中文", TranslateLanguage.KOREAN, TranslateLanguage.CHINESE, "适合韩剧、网页、游戏"),
        LanguagePack("中文 → 英语", TranslateLanguage.CHINESE, TranslateLanguage.ENGLISH, "中文内容翻译成英文"),
        LanguagePack("日语 → 英语", TranslateLanguage.JAPANESE, TranslateLanguage.ENGLISH, "日语翻译成英文"),
        LanguagePack("韩语 → 英语", TranslateLanguage.KOREAN, TranslateLanguage.ENGLISH, "韩语翻译成英文"),
        LanguagePack("法语 → 中文", TranslateLanguage.FRENCH, TranslateLanguage.CHINESE, "法语内容"),
        LanguagePack("德语 → 中文", TranslateLanguage.GERMAN, TranslateLanguage.CHINESE, "德语内容"),
        LanguagePack("西班牙语 → 中文", TranslateLanguage.SPANISH, TranslateLanguage.CHINESE, "西语内容"),
        LanguagePack("俄语 → 中文", TranslateLanguage.RUSSIAN, TranslateLanguage.CHINESE, "俄语内容"),
        LanguagePack("葡萄牙语 → 中文", TranslateLanguage.PORTUGUESE, TranslateLanguage.CHINESE, "葡语内容"),
        LanguagePack("意大利语 → 中文", TranslateLanguage.ITALIAN, TranslateLanguage.CHINESE, "意语内容"),
        LanguagePack("越南语 → 中文", TranslateLanguage.VIETNAMESE, TranslateLanguage.CHINESE, "越南语内容"),
        LanguagePack("泰语 → 中文", TranslateLanguage.THAI, TranslateLanguage.CHINESE, "泰语内容"),
        LanguagePack("印尼语 → 中文", TranslateLanguage.INDONESIAN, TranslateLanguage.CHINESE, "印尼语内容"),
    )

    fun setLanguagePair(source: String, target: String) {
        if (source == currentSource && target == currentTarget && currentTranslator != null) return
        currentTranslator?.close()
        currentSource = source
        currentTarget = target
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source)
            .setTargetLanguage(target)
            .build()
        currentTranslator = Translation.getClient(options)
    }

    fun getCurrentPairDisplay(): String {
        val pack = COMMON_PACKS.find { it.sourceLang == currentSource && it.targetLang == currentTarget }
        return pack?.displayName ?: "$currentSource → $currentTarget"
    }

    fun isTargetChinese(): Boolean = currentTarget == TranslateLanguage.CHINESE

    /** 一键下载指定语言对所需模型 */
    fun downloadLanguagePack(
        source: String,
        target: String,
        requireWifi: Boolean = true,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit,
        onProgress: ((String) -> Unit)? = null
    ) {
        val modelManager = RemoteModelManager.getInstance()
        val conditions = DownloadConditions.Builder().apply {
            if (requireWifi) requireWifi()
        }.build()

        val modelsToDownload = mutableListOf<TranslateRemoteModel>()
        modelsToDownload.add(TranslateRemoteModel.Builder(source).build())
        if (source != target) {
            modelsToDownload.add(TranslateRemoteModel.Builder(target).build())
        }

        downloadSequentially(modelManager, modelsToDownload, conditions, 0, onSuccess, onFailure, onProgress)
    }

    private fun downloadSequentially(
        manager: RemoteModelManager,
        models: List<TranslateRemoteModel>,
        conditions: DownloadConditions,
        index: Int,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit,
        onProgress: ((String) -> Unit)?
    ) {
        if (index >= models.size) {
            onSuccess()
            return
        }
        val model = models[index]
        onProgress?.invoke("正在下载 ${model.language} 模型… (${index + 1}/${models.size})")
        manager.download(model, conditions)
            .addOnSuccessListener {
                downloadSequentially(manager, models, conditions, index + 1, onSuccess, onFailure, onProgress)
            }
            .addOnFailureListener { e -> onFailure(e) }
    }

    suspend fun isModelDownloaded(language: String): Boolean {
        val modelManager = RemoteModelManager.getInstance()
        return try {
            val downloaded = modelManager.getDownloadedModels(TranslateRemoteModel::class.java).await()
            downloaded.any { it.language == language }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getDownloadedLanguages(): Set<String> {
        val modelManager = RemoteModelManager.getInstance()
        return try {
            modelManager.getDownloadedModels(TranslateRemoteModel::class.java).await()
                .map { it.language }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    fun deleteModel(language: String, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val modelManager = RemoteModelManager.getInstance()
        val model = TranslateRemoteModel.Builder(language).build()
        modelManager.deleteDownloadedModel(model)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    suspend fun translate(text: String): String {
        val translator = currentTranslator ?: run {
            setLanguagePair(currentSource, currentTarget)
            currentTranslator!!
        }
        return try {
            translator.translate(text).await()
        } catch (e: Exception) {
            text
        }
    }

    fun close() {
        currentTranslator?.close()
        currentTranslator = null
    }
}
