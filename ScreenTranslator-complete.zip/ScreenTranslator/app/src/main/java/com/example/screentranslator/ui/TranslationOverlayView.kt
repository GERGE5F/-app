package com.example.screentranslator.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import com.example.screentranslator.ocr.TextBlockInfo

/**
 * Edge 风格原地翻译覆盖层
 * 支持根据原文区域亮度自动切换：暗色区域用黑底白字，亮色区域用白底黑字
 */
class TranslationOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class StyledBlock(
        val info: TextBlockInfo,
        val translated: String,
        val isDarkBackground: Boolean  // true = 黑底白字，false = 白底黑字
    )

    private val blocks = mutableListOf<StyledBlock>()

    // 暗色模式画笔（黑底白字）
    private val darkBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E6121212")  // 接近纯黑，高不透明
        style = Paint.Style.FILL
    }
    private val darkTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        isFakeBoldText = true
    }
    private val darkBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#55FFFFFF")
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
    }

    // 亮色模式画笔（白底黑字）
    private val lightBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E6F5F5F5")
        style = Paint.Style.FILL
    }
    private val lightTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF111111")
        typeface = Typeface.DEFAULT_BOLD
        isFakeBoldText = true
    }
    private val lightBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33000000")
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
    }

    fun updateTranslations(data: List<StyledBlock>) {
        blocks.clear()
        blocks.addAll(data)
        invalidate()
    }

    fun clear() {
        blocks.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (block in blocks) {
            val box = block.info.boundingBox
            val rect = RectF(box)

            val bgPaint = if (block.isDarkBackground) darkBgPaint else lightBgPaint
            val textPaint = if (block.isDarkBackground) darkTextPaint else lightTextPaint
            val borderPaint = if (block.isDarkBackground) darkBorderPaint else lightBorderPaint

            // 背景
            canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
            // 边框
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

            // 自适应字号
            val targetHeight = box.height() * 0.7f
            textPaint.textSize = targetHeight.coerceIn(18f, 48f)

            var text = block.translated
            var textWidth = textPaint.measureText(text)

            // 文字过长时缩小字号
            if (textWidth > box.width() * 0.95f && box.width() > 0) {
                textPaint.textSize *= (box.width() * 0.95f / textWidth).coerceAtMost(1f)
                textWidth = textPaint.measureText(text)
            }

            val x = box.left + (box.width() - textWidth) / 2f
            val y = box.top + box.height() * 0.75f

            canvas.drawText(text, x.coerceAtLeast(box.left.toFloat()), y, textPaint)
        }
    }
}
