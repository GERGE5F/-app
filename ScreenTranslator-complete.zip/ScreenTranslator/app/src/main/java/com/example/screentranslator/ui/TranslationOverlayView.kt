package com.example.screentranslator.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.AttributeSet
import android.view.View
import com.example.screentranslator.ocr.TextBlockInfo

/**
 * 小爱式原地翻译：每个文字块单独画，紧贴原文位置，不要整卡片大黑框。
 */
class TranslationOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class StyledBlock(
        val info: TextBlockInfo,
        val translated: String,
        val isDarkBackground: Boolean
    )

    private val blocks = mutableListOf<StyledBlock>()
    private val viewOrigin = IntArray(2)

    private val darkBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC1C1C1C")
        style = Paint.Style.FILL
    }
    private val lightBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCF7F7F7")
        style = Paint.Style.FILL
    }
    private val darkTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT
        isFakeBoldText = false
    }
    private val lightTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF111111")
        typeface = Typeface.DEFAULT
        isFakeBoldText = false
    }

    fun updateTranslations(data: List<StyledBlock>) {
        blocks.clear()
        blocks.addAll(data)
        invalidate()
    }

    fun clear() {
        blocks.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        getLocationOnScreen(viewOrigin)
        val ox = viewOrigin[0]
        val oy = viewOrigin[1]

        for (block in blocks) {
            val box = block.info.boundingBox
            val left = (box.left - ox).toFloat()
            val top = (box.top - oy).toFloat()
            val right = (box.right - ox).toFloat()
            val bottom = (box.bottom - oy).toFloat()

            if (right <= 0 || bottom <= 0 || left >= width || top >= height) continue
            val w = right - left
            val h = bottom - top
            if (w < 8f || h < 8f) continue

            val textPaint = if (block.isDarkBackground) darkTextPaint else lightTextPaint
            val bgPaint = if (block.isDarkBackground) darkBgPaint else lightBgPaint

            val pad = (4f * resources.displayMetrics.density).coerceAtMost(h * 0.12f)
            val text = block.translated
            fitText(textPaint, text, w - pad * 2, h - pad * 2)

            val layout = StaticLayout.Builder
                .obtain(text, 0, text.length, textPaint, (w - pad * 2).toInt().coerceAtLeast(8))
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setIncludePad(false)
                .setLineSpacing(0f, 1f)
                .setMaxLines(6)
                .build()

            val textH = layout.height.toFloat()
            val bgRect = RectF(
                left,
                top,
                right,
                (top + textH + pad * 2).coerceAtMost(bottom + pad)
            )

            canvas.drawRoundRect(bgRect, 4f, 4f, bgPaint)
            canvas.save()
            canvas.clipRect(bgRect)
            canvas.translate(left + pad, top + pad)
            layout.draw(canvas)
            canvas.restore()
        }
    }

    private fun fitText(paint: TextPaint, text: String, maxW: Float, maxH: Float) {
        val min = 10f * resources.displayMetrics.scaledDensity
        val max = (maxH * 0.92f).coerceIn(min, 22f * resources.displayMetrics.scaledDensity)
        paint.textSize = max
        // 按宽度粗略缩小
        val measured = paint.measureText(text)
        if (measured > maxW && maxW > 0) {
            val linesGuess = (measured / maxW).coerceAtLeast(1f)
            val sizeByHeight = (maxH / linesGuess) * 0.9f
            paint.textSize = sizeByHeight.coerceIn(min, max)
        }
        if (paint.textSize < min) paint.textSize = min
    }
}
