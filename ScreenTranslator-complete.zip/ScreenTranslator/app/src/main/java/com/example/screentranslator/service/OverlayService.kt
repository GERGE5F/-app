package com.example.screentranslator.service

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.screentranslator.MainActivity
import com.example.screentranslator.R
import com.example.screentranslator.capture.ScreenCaptureHelper
import com.example.screentranslator.ocr.MlKitOcrHelper
import com.example.screentranslator.ocr.TextBlockInfo
import com.example.screentranslator.translate.MlKitTranslator
import com.example.screentranslator.ui.TranslationOverlayView
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "START"
        const val ACTION_TOGGLE = "TOGGLE"
        const val ACTION_STOP_SERVICE = "STOP_SERVICE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "screen_translator_channel"
        private const val DETECT_INTERVAL_MS = 1000L
        private const val FULL_SCAN_INTERVAL = 8
    }

    private var windowManager: WindowManager? = null
    private var overlayView: TranslationOverlayView? = null

    private var captureHelper: ScreenCaptureHelper? = null
    private val isTranslating = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var lastTextBlocks: List<TextBlockInfo> = emptyList()
    private var detectCount = 0
    private var lastHash: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                if (resultCode != Activity.RESULT_CANCELED && data != null) {
                    initCapture(resultCode, data)
                    windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                    startForeground(NOTIFICATION_ID, createNotification(isRunning = false))
                    Toast.makeText(this, "服务已启动，请在通知栏点击「开始翻译」", Toast.LENGTH_LONG).show()
                }
            }
            ACTION_TOGGLE -> {
                toggleTranslation()
            }
            ACTION_STOP_SERVICE -> {
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun initCapture(resultCode: Int, data: Intent) {
        if (captureHelper == null) {
            captureHelper = ScreenCaptureHelper(this, resultCode, data).also { it.start() }
        }
    }

    private fun toggleTranslation() {
        if (isTranslating.get()) {
            stopTranslationLoop()
            removeOverlay()
            updateNotification(isRunning = false)
            Toast.makeText(this, "翻译已停止", Toast.LENGTH_SHORT).show()
        } else {
            if (captureHelper == null) {
                Toast.makeText(this, "请先从主界面启动服务并授权屏幕录制", Toast.LENGTH_LONG).show()
                return
            }
            isTranslating.set(true)
            ensureOverlay()
            startTranslationLoop()
            updateNotification(isRunning = true)
            Toast.makeText(this, "开始全屏识别 + 每秒快速更新", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ensureOverlay() {
        if (overlayView != null) return
        if (windowManager == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }
        overlayView = TranslationOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // 点击穿透
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        windowManager?.addView(overlayView, params)
    }

    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {}
            overlayView = null
        }
        lastTextBlocks = emptyList()
    }

    private fun startTranslationLoop() {
        scope.launch {
            doFullScanAndTranslate()
            while (isTranslating.get()) {
                delay(DETECT_INTERVAL_MS)
                detectCount++
                val needFull = detectCount % FULL_SCAN_INTERVAL == 0
                if (needFull) {
                    doFullScanAndTranslate()
                } else {
                    doQuickRoiScanAndTranslate()
                }
            }
        }
    }

    private fun stopTranslationLoop() {
        isTranslating.set(false)
    }

    private suspend fun doFullScanAndTranslate() {
        // 优先使用无障碍服务提取文字（更省电、更精准）
        var blocks = withContext(Dispatchers.Default) {
            TextAccessibilityService.extractTextBlocks()
        }

        var bitmap: android.graphics.Bitmap? = null
        var useOcr = false

        if (blocks.isEmpty()) {
            // 无障碍拿不到文字时，回退到截屏 + OCR（适合游戏、图片、WebView 等）
            bitmap = withContext(Dispatchers.IO) {
                captureHelper?.capture()
            }
            if (bitmap != null) {
                blocks = withContext(Dispatchers.Default) {
                    MlKitOcrHelper.recognizeFullScreen(bitmap)
                }
                useOcr = true
            }
        }

        if (blocks.isEmpty()) {
            bitmap?.recycle()
            return
        }

        lastTextBlocks = blocks

        // 有截图时做明暗分析；纯无障碍时默认黑底白字（大多数暗色场景更舒服）
        val styled = if (bitmap != null && useOcr) {
            buildStyledBlocks(bitmap, blocks)
        } else {
            // 无障碍路径：默认按暗色处理，用户可后续扩展
            blocks.map { block ->
                val translated = MlKitTranslator.translate(block.text)
                TranslationOverlayView.StyledBlock(
                    info = block,
                    translated = translated,
                    isDarkBackground = true
                )
            }
        }
        bitmap?.recycle()

        withContext(Dispatchers.Main) {
            overlayView?.updateTranslations(styled)
        }
    }

    private suspend fun doQuickRoiScanAndTranslate() {
        // 快速路径同样优先无障碍
        val a11yBlocks = withContext(Dispatchers.Default) {
            TextAccessibilityService.extractTextBlocks()
        }
        if (a11yBlocks.isNotEmpty()) {
            // 简单内容变化判断：文字拼接哈希
            val contentHash = a11yBlocks.joinToString("|") { it.text }.hashCode().toLong()
            if (contentHash == lastHash && lastTextBlocks.isNotEmpty()) {
                return
            }
            lastHash = contentHash
            lastTextBlocks = a11yBlocks
            val styled = a11yBlocks.map { block ->
                val translated = MlKitTranslator.translate(block.text)
                TranslationOverlayView.StyledBlock(block, translated, isDarkBackground = true)
            }
            withContext(Dispatchers.Main) {
                overlayView?.updateTranslations(styled)
            }
            return
        }

        // 回退 OCR 路径
        if (lastTextBlocks.isEmpty()) {
            doFullScanAndTranslate()
            return
        }

        val bitmap = withContext(Dispatchers.IO) {
            captureHelper?.capture()
        } ?: return

        val currentHash = simpleHash(bitmap)
        if (currentHash == lastHash && lastTextBlocks.isNotEmpty()) {
            bitmap.recycle()
            return
        }
        lastHash = currentHash

        val regions = lastTextBlocks.map { it.boundingBox }
        val newBlocks = withContext(Dispatchers.Default) {
            MlKitOcrHelper.recognizeRoi(bitmap, regions, expandPx = 24)
        }

        if (newBlocks.isNotEmpty()) {
            lastTextBlocks = newBlocks
            val styled = buildStyledBlocks(bitmap, newBlocks)
            bitmap.recycle()
            withContext(Dispatchers.Main) {
                overlayView?.updateTranslations(styled)
            }
        } else {
            bitmap.recycle()
        }
    }

    private suspend fun buildStyledBlocks(
        bitmap: android.graphics.Bitmap,
        blocks: List<TextBlockInfo>
    ): List<TranslationOverlayView.StyledBlock> {
        val darkFlags = withContext(Dispatchers.Default) {
            com.example.screentranslator.ocr.ColorAnalyzer.analyzeBlocks(bitmap, blocks)
        }
        return blocks.mapIndexed { index, block ->
            val translated = MlKitTranslator.translate(block.text)
            TranslationOverlayView.StyledBlock(
                info = block,
                translated = translated,
                isDarkBackground = darkFlags.getOrElse(index) { true }
            )
        }
    }

    private fun simpleHash(bitmap: android.graphics.Bitmap): Long {
        val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 16, 16, true)
        var hash = 0L
        for (y in 0 until 16) {
            for (x in 0 until 16) {
                val pixel = scaled.getPixel(x, y)
                val gray = (android.graphics.Color.red(pixel) +
                        android.graphics.Color.green(pixel) +
                        android.graphics.Color.blue(pixel)) / 3
                if (gray > 128) hash = hash or (1L shl (y * 16 + x))
            }
        }
        scaled.recycle()
        return hash
    }

    private fun createNotification(isRunning: Boolean): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "屏幕翻译服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "控制屏幕翻译的开关"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }

        // 打开主界面
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        // 开始/停止翻译
        val toggleIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // 完全停止服务
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val title = if (isRunning) "屏幕翻译 · 运行中" else "屏幕翻译 · 已就绪"
        val text = if (isRunning) {
            "正在翻译 · ${MlKitTranslator.getCurrentPairDisplay()}\n点击「停止翻译」可关闭覆盖层"
        } else {
            "点击「开始翻译」启动全屏识别"
        }
        val toggleLabel = if (isRunning) "停止翻译" else "开始翻译"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                android.R.drawable.ic_media_play,
                toggleLabel,
                toggleIntent
            )
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "退出服务",
                stopIntent
            )
            .build()
    }

    private fun updateNotification(isRunning: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, createNotification(isRunning))
    }

    override fun onDestroy() {
        stopTranslationLoop()
        removeOverlay()
        captureHelper?.stop()
        MlKitTranslator.close()
        scope.cancel()
        super.onDestroy()
    }
}
