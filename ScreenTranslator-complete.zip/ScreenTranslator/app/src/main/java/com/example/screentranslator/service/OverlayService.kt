package com.example.screentranslator.service

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.screentranslator.MainActivity
import com.example.screentranslator.R
import com.example.screentranslator.capture.ScreenCaptureHelper
import com.example.screentranslator.ocr.MlKitOcrHelper
import com.example.screentranslator.ocr.TextBlockInfo
import com.example.screentranslator.translate.MlKitTranslator
import com.example.screentranslator.ui.TranslationOverlayView
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "START"
        const val ACTION_TOGGLE = "TOGGLE"
        const val ACTION_STOP_SERVICE = "STOP_SERVICE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "screen_translator_channel_v2"
        private const val DETECT_INTERVAL_MS = 1000L
        private const val FULL_SCAN_INTERVAL = 8
    }

    private var windowManager: WindowManager? = null
    private var overlayView: TranslationOverlayView? = null
    private var captureHelper: ScreenCaptureHelper? = null
    private val isTranslating = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var lastTextBlocks: List<TextBlockInfo> = emptyList()
    private var detectCount = 0
    private var lastHash: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // 尽早创建通知渠道
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 必须立刻 startForeground，否则 Android 8+ 会在超时后杀服务
        val notification = createNotification(isRunning = isTranslating.get())
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // 降级：不带 type 再试一次
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (e2: Exception) {
                e2.printStackTrace()
            }
        }

        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                if (resultCode != Activity.RESULT_CANCELED && data != null) {
                    try {
                        initCapture(resultCode, data)
                        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                        updateNotification(isRunning = false)
                        Toast.makeText(this, "服务已启动，请看通知栏「开始翻译」", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "启动失败: ${e.message}", Toast.LENGTH_LONG).show()
                        e.printStackTrace()
                    }
                } else {
                    Toast.makeText(this, "请允许屏幕录制权限后重试", Toast.LENGTH_LONG).show()
                }
            }
            ACTION_TOGGLE -> toggleTranslation()
            ACTION_STOP_SERVICE -> {
                stopTranslationLoop()
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun initCapture(resultCode: Int, data: Intent) {
        captureHelper?.stop()
        captureHelper = ScreenCaptureHelper(this, resultCode, data).also { it.start() }
    }

    private fun toggleTranslation() {
        if (isTranslating.get()) {
            stopTranslationLoop()
            removeOverlay()
            updateNotification(isRunning = false)
            Toast.makeText(this, "翻译已停止", Toast.LENGTH_SHORT).show()
        } else {
            if (captureHelper == null) {
                // 无障碍仍可用，允许无截屏也启动
                Toast.makeText(this, "未获得录屏权限，将仅使用无障碍取字", Toast.LENGTH_LONG).show()
            }
            isTranslating.set(true)
            ensureOverlay()
            startTranslationLoop()
            updateNotification(isRunning = true)
            Toast.makeText(this, "开始翻译", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ensureOverlay() {
        if (overlayView != null) return
        if (windowManager == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        }
        try {
            overlayView = TranslationOverlayView(this)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            Toast.makeText(this, "无法显示覆盖层，请开启悬浮窗权限", Toast.LENGTH_LONG).show()
            e.printStackTrace()
            isTranslating.set(false)
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
            overlayView = null
        }
        lastTextBlocks = emptyList()
    }

    private fun startTranslationLoop() {
        scope.launch {
            doFullScanAndTranslate()
            while (isTranslating.get()) {
                delay(DETECT_INTERVAL_MS)
                detectCount++
                if (detectCount % FULL_SCAN_INTERVAL == 0) {
                    doFullScanAndTranslate()
                } else {
                    doQuickRoiScanAndTranslate()
                }
            }
        }
    }

    private fun stopTranslationLoop() {
        isTranslating.set(false)
    }

    private suspend fun doFullScanAndTranslate() {
        var blocks = withContext(Dispatchers.Default) {
            TextAccessibilityService.extractTextBlocks()
        }

        var bitmap: android.graphics.Bitmap? = null
        var useOcr = false

        if (blocks.isEmpty()) {
            bitmap = withContext(Dispatchers.IO) { captureHelper?.capture() }
            if (bitmap != null) {
                blocks = withContext(Dispatchers.Default) {
                    MlKitOcrHelper.recognizeFullScreen(bitmap)
                }
                useOcr = true
            }
        }

        if (blocks.isEmpty()) {
            bitmap?.recycle()
            return
        }

        lastTextBlocks = blocks
        val styled = if (bitmap != null && useOcr) {
            buildStyledBlocks(bitmap, blocks)
        } else {
            blocks.map { block ->
                val translated = MlKitTranslator.translate(block.text)
                TranslationOverlayView.StyledBlock(block, translated, isDarkBackground = true)
            }
        }
        bitmap?.recycle()

        withContext(Dispatchers.Main) {
            overlayView?.updateTranslations(styled)
        }
    }

    private suspend fun doQuickRoiScanAndTranslate() {
        val a11yBlocks = withContext(Dispatchers.Default) {
            TextAccessibilityService.extractTextBlocks()
        }
        if (a11yBlocks.isNotEmpty()) {
            val contentHash = a11yBlocks.joinToString("|") { it.text }.hashCode().toLong()
            if (contentHash == lastHash && lastTextBlocks.isNotEmpty()) return
            lastHash = contentHash
            lastTextBlocks = a11yBlocks
            val styled = a11yBlocks.map { block ->
                val translated = MlKitTranslator.translate(block.text)
                TranslationOverlayView.StyledBlock(block, translated, isDarkBackground = true)
            }
            withContext(Dispatchers.Main) {
                overlayView?.updateTranslations(styled)
            }
            return
        }

        if (lastTextBlocks.isEmpty()) {
            doFullScanAndTranslate()
            return
        }

        val bitmap = withContext(Dispatchers.IO) { captureHelper?.capture() } ?: return
        val currentHash = simpleHash(bitmap)
        if (currentHash == lastHash && lastTextBlocks.isNotEmpty()) {
            bitmap.recycle()
            return
        }
        lastHash = currentHash

        val regions = lastTextBlocks.map { it.boundingBox }
        val newBlocks = withContext(Dispatchers.Default) {
            MlKitOcrHelper.recognizeRoi(bitmap, regions, expandPx = 24)
        }

        if (newBlocks.isNotEmpty()) {
            lastTextBlocks = newBlocks
            val styled = buildStyledBlocks(bitmap, newBlocks)
            bitmap.recycle()
            withContext(Dispatchers.Main) {
                overlayView?.updateTranslations(styled)
            }
        } else {
            bitmap.recycle()
        }
    }

    private suspend fun buildStyledBlocks(
        bitmap: android.graphics.Bitmap,
        blocks: List<TextBlockInfo>
    ): List<TranslationOverlayView.StyledBlock> {
        val darkFlags = withContext(Dispatchers.Default) {
            com.example.screentranslator.ocr.ColorAnalyzer.analyzeBlocks(bitmap, blocks)
        }
        return blocks.mapIndexed { index, block ->
            val translated = MlKitTranslator.translate(block.text)
            TranslationOverlayView.StyledBlock(
                info = block,
                translated = translated,
                isDarkBackground = darkFlags.getOrElse(index) { true }
            )
        }
    }

    private fun simpleHash(bitmap: android.graphics.Bitmap): Long {
        val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 16, 16, true)
        var hash = 0L
        for (y in 0 until 16) {
            for (x in 0 until 16) {
                val pixel = scaled.getPixel(x, y)
                val gray = (android.graphics.Color.red(pixel) +
                        android.graphics.Color.green(pixel) +
                        android.graphics.Color.blue(pixel)) / 3
                if (gray > 128) hash = hash or (1L shl (y * 16 + x))
            }
        }
        scaled.recycle()
        return hash
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "屏幕翻译服务",
                NotificationManager.IMPORTANCE_DEFAULT  // 不用 LOW，避免被系统隐藏
            ).apply {
                description = "控制屏幕翻译开关"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun createNotification(isRunning: Boolean): Notification {
        createNotificationChannel()

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val title = if (isRunning) "屏幕翻译 · 运行中" else "屏幕翻译 · 已就绪"
        val text = if (isRunning) {
            "正在翻译 · ${MlKitTranslator.getCurrentPairDisplay()}"
        } else {
            "点击「开始翻译」启动识别"
        }
        val toggleLabel = if (isRunning) "停止翻译" else "开始翻译"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_media_play, toggleLabel, toggleIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "退出", stopIntent)
            .build()
    }

    private fun updateNotification(isRunning: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, createNotification(isRunning))
    }

    override fun onDestroy() {
        stopTranslationLoop()
        removeOverlay()
        captureHelper?.stop()
        MlKitTranslator.close()
        scope.cancel()
        super.onDestroy()
    }
}
