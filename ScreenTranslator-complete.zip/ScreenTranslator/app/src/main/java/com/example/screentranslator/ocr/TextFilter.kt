package com.example.screentranslator.ocr

import android.graphics.Rect
import android.util.DisplayMetrics

/**
 * 过滤不该翻译的文字块：
 * - 屏幕外 / 几乎看不见
 * - 过大的容器框
 * - 图片上的哈希/乱码
 * - 已经是目标语言的文字
 */
object TextFilter {

    private val HEX_HASH = Regex("^[0-9a-fA-F]{6,}$")
    private val MOSTLY_HEX = Regex("^[0-9a-fA-F\\s\\-_]{8,}$")

    fun isOnScreen(box: Rect, metrics: DisplayMetrics, minVisibleRatio: Float = 0.55f): Boolean {
        val screen = Rect(0, 0, metrics.widthPixels, metrics.heightPixels)
        val vis = Rect(box)
        if (!vis.intersect(screen)) return false
        val boxArea = box.width().toLong() * box.height().toLong()
        if (boxArea <= 0) return false
        val visArea = vis.width().toLong() * vis.height().toLong()
        return visArea.toFloat() / boxArea >= minVisibleRatio
    }

    /** 整页/整卡片的巨大框，不单独盖一层黑底 */
    fun isGiantContainer(box: Rect, metrics: DisplayMetrics): Boolean {
        val sw = metrics.widthPixels.coerceAtLeast(1)
        val sh = metrics.heightPixels.coerceAtLeast(1)
        val areaRatio = (box.width().toFloat() * box.height()) / (sw * sh)
        if (areaRatio > 0.22f) return true
        if (box.width() > sw * 0.92f && box.height() > sh * 0.18f) return true
        if (box.height() > sh * 0.40f) return true
        return false
    }

    fun isNoiseText(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return true
        if (t.length == 1 && !t[0].isLetterOrDigit() && t[0] !in '\u4e00'..'\u9fff') return true
        if (HEX_HASH.matches(t) || MOSTLY_HEX.matches(t)) return true
        // 图片上常见的无意义识别结果
        if (t.length in 6..20 && t.all { it.isLetterOrDigit() } && t.any { it.isDigit() } && t.any { it.isLetter() }) {
            val letters = t.count { it.isLetter() }
            val digits = t.count { it.isDigit() }
            if (letters >= 4 && digits >= 4 && t.none { it == ' ' }) return true
        }
        return false
    }

    fun looksAlreadyChinese(text: String): Boolean {
        val letters = text.filter { it.isLetter() || it in '\u4e00'..'\u9fff' }
        if (letters.isEmpty()) return false
        val cjk = letters.count { it in '\u4e00'..'\u9fff' }
        return cjk >= letters.length * 0.55f
    }

    fun sanitize(blocks: List<TextBlockInfo>, metrics: DisplayMetrics): List<TextBlockInfo> {
        return blocks
            .asSequence()
            .map { it.copy(text = it.text.trim()) }
            .filter { it.text.isNotBlank() }
            .filter { !isNoiseText(it.text) }
            .filter { isOnScreen(it.boundingBox, metrics) }
            .filter { !isGiantContainer(it.boundingBox, metrics) }
            .filter { it.boundingBox.width() >= 10 && it.boundingBox.height() >= 10 }
            .distinctBy { "${it.boundingBox.flattenToString()}|${it.text}" }
            .toList()
    }
}
