package com.example.screentranslator.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class TextBlockInfo(
    val text: String,
    val boundingBox: Rect,
    val confidence: Float = 1.0f
)

object MlKitOcrHelper {

    private val chineseRecognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    private val latinRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /**
     * 全屏 OCR：按「行」取框，避免整段合成一张大黑底。
     */
    suspend fun recognizeFullScreen(bitmap: Bitmap): List<TextBlockInfo> {
        val image = InputImage.fromBitmap(bitmap, 0)
        return try {
            linesFrom(chineseRecognizer.process(image).await())
        } catch (_: Exception) {
            try {
                linesFrom(latinRecognizer.process(image).await())
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    suspend fun recognizeRoi(
        bitmap: Bitmap,
        regions: List<Rect>,
        expandPx: Int = 16
    ): List<TextBlockInfo> {
        if (regions.isEmpty()) return emptyList()
        val results = mutableListOf<TextBlockInfo>()
        for (region in regions) {
            val left = (region.left - expandPx).coerceAtLeast(0)
            val top = (region.top - expandPx).coerceAtLeast(0)
            val right = (region.right + expandPx).coerceAtMost(bitmap.width)
            val bottom = (region.bottom + expandPx).coerceAtMost(bitmap.height)
            if (right <= left || bottom <= top) continue

            val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            try {
                val image = InputImage.fromBitmap(cropped, 0)
                val lines = try {
                    linesFrom(chineseRecognizer.process(image).await())
                } catch (_: Exception) {
                    emptyList()
                }
                for (line in lines) {
                    val box = line.boundingBox
                    results.add(
                        TextBlockInfo(
                            line.text,
                            Rect(
                                box.left + left,
                                box.top + top,
                                box.right + left,
                                box.bottom + top
                            )
                        )
                    )
                }
            } catch (_: Exception) {
            } finally {
                cropped.recycle()
            }
        }
        return results.filter { it.text.isNotBlank() }
    }

    private fun linesFrom(result: com.google.mlkit.vision.text.Text): List<TextBlockInfo> {
        val out = mutableListOf<TextBlockInfo>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                val t = line.text.trim()
                if (t.isBlank()) continue
                out.add(TextBlockInfo(t, box))
            }
        }
        return out
    }
}
