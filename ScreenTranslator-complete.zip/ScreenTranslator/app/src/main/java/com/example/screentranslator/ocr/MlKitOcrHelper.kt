package com.example.screentranslator.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class TextBlockInfo(
    val text: String,
    val boundingBox: Rect,
    val confidence: Float = 1.0f
)

object MlKitOcrHelper {

    // 优先中文识别器，失败可回退 Latin
    private val chineseRecognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    private val latinRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /**
     * 全屏 OCR：识别所有文字位置
     */
    suspend fun recognizeFullScreen(bitmap: Bitmap): List<TextBlockInfo> {
        val image = InputImage.fromBitmap(bitmap, 0)
        return try {
            val result = chineseRecognizer.process(image).await()
            result.textBlocks.mapNotNull { block ->
                val box = block.boundingBox ?: return@mapNotNull null
                TextBlockInfo(
                    text = block.text.trim(),
                    boundingBox = box,
                    confidence = 1.0f
                )
            }.filter { it.text.isNotBlank() }
        } catch (e: Exception) {
            // 回退 Latin
            try {
                val result = latinRecognizer.process(image).await()
                result.textBlocks.mapNotNull { block ->
                    val box = block.boundingBox ?: return@mapNotNull null
                    TextBlockInfo(block.text.trim(), box)
                }.filter { it.text.isNotBlank() }
            } catch (e2: Exception) {
                emptyList()
            }
        }
    }

    /**
     * 快速 ROI OCR：只识别指定区域（扩大一点边距）
     * 用于每秒快速再识别已有文字位置
     */
    suspend fun recognizeRoi(bitmap: Bitmap, regions: List<Rect>, expandPx: Int = 20): List<TextBlockInfo> {
        if (regions.isEmpty()) return emptyList()

        val results = mutableListOf<TextBlockInfo>()
        for (region in regions) {
            val left = (region.left - expandPx).coerceAtLeast(0)
            val top = (region.top - expandPx).coerceAtLeast(0)
            val right = (region.right + expandPx).coerceAtMost(bitmap.width)
            val bottom = (region.bottom + expandPx).coerceAtMost(bitmap.height)

            if (right <= left || bottom <= top) continue

            val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            val image = InputImage.fromBitmap(cropped, 0)

            try {
                val result = chineseRecognizer.process(image).await()
                result.textBlocks.forEach { block ->
                    val box = block.boundingBox ?: return@forEach
                    // 坐标转换回全屏
                    val globalBox = Rect(
                        box.left + left,
                        box.top + top,
                        box.right + left,
                        box.bottom + top
                    )
                    results.add(TextBlockInfo(block.text.trim(), globalBox))
                }
            } catch (_: Exception) {
                // 忽略单个区域失败
            } finally {
                cropped.recycle()
            }
        }
        return results.filter { it.text.isNotBlank() }
    }
}
