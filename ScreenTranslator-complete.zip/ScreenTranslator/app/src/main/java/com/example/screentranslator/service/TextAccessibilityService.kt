package com.example.screentranslator.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.screentranslator.ocr.TextBlockInfo

/**
 * 无障碍服务：从当前窗口节点树提取文字 + 位置
 * 比 MediaProjection 截屏更省电，对原生 App 更精准
 */
class TextAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TextAccessibilityService? = null

        /**
         * 获取当前屏幕可见文字块（带坐标）
         */
        fun extractTextBlocks(): List<TextBlockInfo> {
            val service = instance ?: return emptyList()
            val root = service.rootInActiveWindow ?: return emptyList()
            val results = mutableListOf<TextBlockInfo>()
            try {
                traverse(root, results)
            } catch (_: Exception) {
            } finally {
                root.recycle()
            }
            return results.filter { it.text.isNotBlank() }
        }

        private fun traverse(node: AccessibilityNodeInfo, out: MutableList<TextBlockInfo>) {
            // 只取可见且有文字的节点
            if (node.isVisibleToUser) {
                val text = node.text?.toString()?.trim()
                    ?: node.contentDescription?.toString()?.trim()
                if (!text.isNullOrBlank() && text.length >= 1) {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    // 过滤太小的区域（可能是图标）
                    if (rect.width() > 8 && rect.height() > 8) {
                        out.add(TextBlockInfo(text, Rect(rect)))
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                try {
                    traverse(child, out)
                } finally {
                    child.recycle()
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 不需要实时监听，按需主动提取即可
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
