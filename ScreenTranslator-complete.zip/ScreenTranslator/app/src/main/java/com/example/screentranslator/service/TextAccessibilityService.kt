package com.example.screentranslator.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.screentranslator.ocr.TextBlockInfo
import com.example.screentranslator.ocr.TextFilter

/**
 * 无障碍取字：只取可见的「叶子文字节点」，跳过图片、屏幕外、巨大容器。
 */
class TextAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TextAccessibilityService? = null

        fun extractTextBlocks(): List<TextBlockInfo> {
            val service = instance ?: return emptyList()
            val root = service.rootInActiveWindow ?: return emptyList()
            val results = mutableListOf<TextBlockInfo>()
            val metrics = service.currentMetrics()
            try {
                traverse(root, results, metrics)
            } catch (_: Exception) {
            } finally {
                root.recycle()
            }
            return TextFilter.sanitize(results, metrics)
        }

        private fun TextAccessibilityService.currentMetrics(): DisplayMetrics {
            val metrics = DisplayMetrics()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                metrics.widthPixels = bounds.width()
                metrics.heightPixels = bounds.height()
                metrics.density = resources.displayMetrics.density
            } else {
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(metrics)
            }
            return metrics
        }

        private fun traverse(
            node: AccessibilityNodeInfo,
            out: MutableList<TextBlockInfo>,
            metrics: DisplayMetrics
        ) {
            val pkg = node.packageName?.toString().orEmpty()
            if (pkg == "com.example.screentranslator") {
                return
            }

            val childCount = node.childCount
            var hasTextChild = false
            val children = ArrayList<AccessibilityNodeInfo>(childCount)
            for (i in 0 until childCount) {
                val child = node.getChild(i) ?: continue
                children.add(child)
                if (nodeLooksLikeText(child)) hasTextChild = true
            }

            if (node.isVisibleToUser && !isImageLike(node) && !hasTextChild) {
                val raw = node.text?.toString()?.trim()
                // 不用 contentDescription：图片 alt 会盖到图上
                if (!raw.isNullOrBlank()) {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    if (!TextFilter.isGiantContainer(rect, metrics) &&
                        TextFilter.isOnScreen(rect, metrics)
                    ) {
                        out.add(TextBlockInfo(raw, Rect(rect)))
                    }
                }
            }

            for (child in children) {
                try {
                    traverse(child, out, metrics)
                } finally {
                    child.recycle()
                }
            }
        }

        private fun nodeLooksLikeText(node: AccessibilityNodeInfo): Boolean {
            if (!node.text.isNullOrBlank()) return true
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                try {
                    if (nodeLooksLikeText(c)) return true
                } finally {
                    c.recycle()
                }
            }
            return false
        }

        private fun isImageLike(node: AccessibilityNodeInfo): Boolean {
            val cls = node.className?.toString().orEmpty()
            val lower = cls.lowercase()
            if (lower.contains("imageview") ||
                lower.contains("imagebutton") ||
                lower.contains("thumbnail") ||
                lower.endsWith(".image") ||
                lower.contains("photoview") ||
                lower.contains("drawee")
            ) return true
            // 只有描述没有真正文字的，多半是图片/图标
            if (node.text.isNullOrBlank() && !node.contentDescription.isNullOrBlank()) return true
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
