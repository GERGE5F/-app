package com.example.screentranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.screentranslator.service.OverlayService
import com.example.screentranslator.translate.MlKitTranslator
import com.google.mlkit.nl.translate.TranslateLanguage

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var packContainer: LinearLayout
    private lateinit var btnAccessibility: Button

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            requestScreenCapture()
        } else {
            Toast.makeText(this, "需要悬浮窗权限才能显示翻译层", Toast.LENGTH_LONG).show()
        }
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
                putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(OverlayService.EXTRA_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            statusText.text = "翻译服务已启动\n当前语言：${MlKitTranslator.getCurrentPairDisplay()}\n请在通知栏点击「开始翻译」"
            Toast.makeText(this, "服务已启动", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "需要屏幕录制权限", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        packContainer = findViewById(R.id.languagePackContainer)
        btnAccessibility = findViewById(R.id.btnAccessibility)

        btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "请找到「屏幕翻译」并开启无障碍服务", Toast.LENGTH_LONG).show()
        }

        // 默认英→中
        MlKitTranslator.setLanguagePair(TranslateLanguage.ENGLISH, TranslateLanguage.CHINESE)

        setupLanguagePacks()

        btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            } else {
                requestScreenCapture()
            }
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            statusText.text = "服务已停止"
        }
    }

    private fun setupLanguagePacks() {
        packContainer.removeAllViews()

        for (pack in MlKitTranslator.COMMON_PACKS) {
            val btn = Button(this).apply {
                text = "${pack.displayName}\n${pack.description}"
                textSize = 13f
                isAllCaps = false
                setPadding(24, 20, 24, 20)
                setOnClickListener {
                    downloadAndSetPack(pack)
                }
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 10
            }
            packContainer.addView(btn, params)
        }
    }

    private fun downloadAndSetPack(pack: MlKitTranslator.LanguagePack) {
        statusText.text = "正在下载：${pack.displayName}…"
        Toast.makeText(this, "开始下载 ${pack.displayName}（建议 WiFi）", Toast.LENGTH_SHORT).show()

        MlKitTranslator.downloadLanguagePack(
            source = pack.sourceLang,
            target = pack.targetLang,
            requireWifi = false,
            onSuccess = {
                runOnUiThread {
                    MlKitTranslator.setLanguagePair(pack.sourceLang, pack.targetLang)
                    statusText.text = "✓ ${pack.displayName} 已就绪，可离线使用"
                    Toast.makeText(this, "${pack.displayName} 下载完成", Toast.LENGTH_SHORT).show()
                }
            },
            onFailure = { e ->
                runOnUiThread {
                    statusText.text = "下载失败：${e.message}\n请检查网络后重试"
                    Toast.makeText(this, "下载失败", Toast.LENGTH_SHORT).show()
                }
            },
            onProgress = { msg ->
                runOnUiThread {
                    statusText.text = msg
                }
            }
        )
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
