package com.example.screentranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.screentranslator.service.OverlayService
import com.example.screentranslator.translate.MlKitTranslator
import com.google.mlkit.nl.translate.TranslateLanguage

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var currentLangText: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnAccessibility: Button
    private lateinit var btnMenu: View

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            requestScreenCapture()
        } else {
            Toast.makeText(this, "需要悬浮窗权限才能显示翻译层", Toast.LENGTH_LONG).show()
        }
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
                putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(OverlayService.EXTRA_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            statusText.text = "翻译服务已启动\n当前：${MlKitTranslator.getCurrentPairDisplay()}\n请在通知栏点击「开始翻译」"
            Toast.makeText(this, "服务已启动", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "需要屏幕录制权限", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        currentLangText = findViewById(R.id.currentLangText)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnAccessibility = findViewById(R.id.btnAccessibility)
        btnMenu = findViewById(R.id.btnMenu)

        MlKitTranslator.setLanguagePair(TranslateLanguage.ENGLISH, TranslateLanguage.CHINESE)
        refreshLangLabel()

        btnMenu.setOnClickListener { showOverflow(it) }

        btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "请找到「屏幕翻译」并开启无障碍服务", Toast.LENGTH_LONG).show()
        }

        btnStart.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        1001
                    )
                }
            }
            if (!Settings.canDrawOverlays(this)) {
                overlayPermissionLauncher.launch(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                requestScreenCapture()
            }
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            statusText.text = "服务已停止"
        }
    }

    override fun onResume() {
        super.onResume()
        refreshLangLabel()
    }

    private fun refreshLangLabel() {
        currentLangText.text = "当前语言：${MlKitTranslator.getCurrentPairDisplay()}\n语言包下载：右上角 ⋮ → 语言包"
    }

    private fun showOverflow(anchor: View) {
        PopupMenu(this, anchor).apply {
            menuInflater.inflate(R.menu.menu_main, menu)
            setOnMenuItemClickListener { item ->
                if (item.itemId == R.id.action_language_packs) {
                    startActivity(Intent(this@MainActivity, LanguagePackActivity::class.java))
                    true
                } else false
            }
            show()
        }
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
