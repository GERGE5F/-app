package com.example.screentranslator

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.screentranslator.translate.MlKitTranslator

class LanguagePackActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var packContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language_packs)

        statusText = findViewById(R.id.packStatusText)
        packContainer = findViewById(R.id.languagePackContainer)
        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        setupLanguagePacks()
    }

    private fun setupLanguagePacks() {
        packContainer.removeAllViews()
        for (pack in MlKitTranslator.COMMON_PACKS) {
            val btn = Button(this).apply {
                text = "${pack.displayName}\n${pack.description}"
                textSize = 13f
                isAllCaps = false
                setPadding(24, 20, 24, 20)
                setOnClickListener { downloadAndSetPack(pack) }
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 }
            packContainer.addView(btn, params)
        }
    }

    private fun downloadAndSetPack(pack: MlKitTranslator.LanguagePack) {
        statusText.text = "正在下载：${pack.displayName}…"
        Toast.makeText(this, "开始下载 ${pack.displayName}", Toast.LENGTH_SHORT).show()
        MlKitTranslator.downloadLanguagePack(
            source = pack.sourceLang,
            target = pack.targetLang,
            requireWifi = false,
            onSuccess = {
                runOnUiThread {
                    MlKitTranslator.setLanguagePair(pack.sourceLang, pack.targetLang)
                    statusText.text = "✓ ${pack.displayName} 已就绪，可离线使用"
                    Toast.makeText(this, "${pack.displayName} 下载完成", Toast.LENGTH_SHORT).show()
                }
            },
            onFailure = { e ->
                runOnUiThread {
                    statusText.text = "下载失败：${e.message}\n请检查网络后重试"
                    Toast.makeText(this, "下载失败", Toast.LENGTH_SHORT).show()
                }
            },
            onProgress = { msg ->
                runOnUiThread { statusText.text = msg }
            }
        )
    }
}
