package com.example.screentranslator.ocr

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect

/**
 * 分析文字区域背景亮度，判断是否为暗色模式
 */
object ColorAnalyzer {

    /**
     * 采样 bounding box 区域的平均亮度
     * 返回 true 表示暗色背景（应使用黑底白字）
     */
    fun isDarkBackground(bitmap: Bitmap, box: Rect, sampleStep: Int = 4): Boolean {
        val left = box.left.coerceIn(0, bitmap.width - 1)
        val top = box.top.coerceIn(0, bitmap.height - 1)
        val right = box.right.coerceIn(0, bitmap.width)
        val bottom = box.bottom.coerceIn(0, bitmap.height)

        if (right <= left || bottom <= top) return true  // 默认暗色

        var totalLuminance = 0.0
        var count = 0

        // 均匀采样，避免处理每个像素
        for (y in top until bottom step sampleStep) {
            for (x in left until right step sampleStep) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                // 感知亮度公式
                val luminance = 0.299 * r + 0.587 * g + 0.114 * b
                totalLuminance += luminance
                count++
            }
        }

        if (count == 0) return true

        val avg = totalLuminance / count
        // 阈值：低于 128 认为是暗色背景（黑底白字更合适）
        return avg < 128
    }

    /**
     * 批量分析多个文字块
     */
    fun analyzeBlocks(bitmap: Bitmap, blocks: List<TextBlockInfo>): List<Boolean> {
        return blocks.map { isDarkBackground(bitmap, it.boundingBox) }
    }
}
