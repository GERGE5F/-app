# 屏幕翻译 (Screen Translator)

效果类似 **Edge 浏览器自带翻译** 的 Android 屏幕翻译应用。

## 功能一览

- **Edge 风格原地覆盖**：翻译文字精确盖在原文位置
- **点击穿透**：翻译层不拦截触摸，底层 App 可正常操作
- **智能明暗适配**：暗色区域自动黑底白字，亮色区域白底黑字
- **双通道取字**：
  - 优先 **无障碍服务**（更省电、更准）
  - 回退 **MediaProjection + ML Kit OCR**（游戏/图片/WebView）
- **智能刷新**：每秒检测变化，有变化才更新；支持 ROI 局部再识别
- **常用语言包一键下载**：15 个常用语言对，下载后完全离线
- **通知栏控制**：无悬浮球，通知栏「开始翻译 / 停止翻译 / 退出服务」

## 内置语言包

英语/日语/韩语 ↔ 中文、英语；法语/德语/西语/俄语/葡语/意语/越南语/泰语/印尼语 → 中文

## 快速开始

### 环境要求

- Android Studio Hedgehog 或更新版本
- JDK 17
- 真机 Android 8.0+（推荐 10+）

### 打开与运行

1. 用 Android Studio 打开本目录 `ScreenTranslator`
2. 等待 Gradle 同步完成
3. 连接真机，点击 Run
4. 首次运行顺序：
   1. 下载需要的语言包
   2. 开启无障碍权限（设置 → 无障碍 → 屏幕翻译）
   3. 启动翻译服务（授予悬浮窗 + 屏幕录制）
   4. 通知栏点击「开始翻译」

### 权限说明

| 权限 | 用途 |
|------|------|
| 悬浮窗 | 显示翻译覆盖层 |
| 无障碍 | 读取当前界面文字节点（推荐） |
| 屏幕录制 | OCR 回退方案 |
| 通知 | 前台服务与开关控制 |

## 项目结构

```
app/src/main/java/com/example/screentranslator/
├── MainActivity.kt                 # 权限引导 + 语言包下载
├── capture/ScreenCaptureHelper.kt  # MediaProjection 截屏
├── ocr/
│   ├── MlKitOcrHelper.kt           # 全屏 / ROI OCR
│   └── ColorAnalyzer.kt            # 明暗分析
├── translate/MlKitTranslator.kt    # 离线翻译 + 语言包管理
├── service/
│   ├── OverlayService.kt           # 前台服务 + 翻译循环 + 通知控制
│   └── TextAccessibilityService.kt # 无障碍取字
└── ui/TranslationOverlayView.kt    # 穿透覆盖层绘制
```

## 技术栈

- Kotlin
- ML Kit Text Recognition v2 + On-device Translation
- MediaProjection / AccessibilityService
- WindowManager 悬浮窗（FLAG_NOT_TOUCHABLE）
- Coroutines

## 注意事项

- 必须使用真机，模拟器无法完整体验 MediaProjection
- 部分国产系统需额外允许「后台弹出界面」「显示悬浮窗」
- 语言包每个约 30MB，建议 WiFi 下载
- 无障碍服务仅在翻译时主动读取当前窗口，不后台收集数据

## License

示例项目，可自由修改使用。

---

## 使用 GitHub Actions 自动打包 APK

1. 在 GitHub 新建仓库，把本项目全部文件推上去：

```bash
git init
git add .
git commit -m "Screen Translator"
git branch -M main
git remote add origin https://github.com/你的用户名/ScreenTranslator.git
git push -u origin main
```

2. 打开仓库页面 → **Actions** 标签
3. 选择 **Build APK** → **Run workflow**（或推送代码后自动运行）
4. 等待约 3～8 分钟，绿色对勾后进入该次运行
5. 底部 **Artifacts** 下载 `ScreenTranslator-debug`
6. 解压得到 `app-debug.apk`，传到手机安装即可

> 手动触发：Actions → Build APK → Run workflow → Run
